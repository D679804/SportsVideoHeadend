import glob
import json
import os
import uuid
import boto3
import datetime
import random
from urllib.parse import urlparse
import logging

from botocore.client import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

S3 = boto3.resource('s3')

def handler(event, context):
    
    '''
    convert.py read input json which defines the VOD convert job source file, destination and job template to use.
    convert.py will choose the suitable job template to use according to job template defined in input json.
    start convert job.
    1.Create VOD job. POST /vodconvert/create_job
        {
            "Record": {
                "Platform": "1",    // Encoding platform. 1 - AWS MediaService
                "AssetID": "sample4",   //Asset unique ID
                "JobTemplateName": "telstra_awsvod_highprofile_hls_jobtemp",    //Encoding job template name
                "Source": {     //Source file location
                    "object": {
                        "key": "input/sample.mp4"
                    },
                    "bucket": {
                        "name": "telstra-awsvod-watchfolder"
                    }
                },
                "Destination": {    //Encoded file location
                    "bucket": {
                        "name": "telstra-awsvod-encoded"
                    }
                }
            }
        }
    '''
    job_body = {}
    job_body = json.loads(event['body'])
    print(job_body)
    
    if job_body['Record']['Platform'] == "1": 
        #Construct S3 Source resource. Define S3 source bucket and key.
        sourceS3Bucket = job_body['Record']['Source']['bucket']['name']
        sourceS3Key = job_body['Record']['Source']['object']['key']
        sourceS3 = 's3://'+ sourceS3Bucket + '/' + sourceS3Key
    
        #Construct S3 Destination resource. Define S3 destination bucket
        destinationS3Bucket = job_body['Record']['Destination']['bucket']['name']
        destinationS3 = 's3://' + destinationS3Bucket
    
        #Read and parse input json Event. Ddfines jobTemplate to use, asset ID,     
        jobTemplateName = job_body['Record']['JobTemplateName']
        assetID = job_body['Record']['AssetID']
    
        #Retrieve environment variables e.g. MediaConvert Role, MediaConvert Account endPoint URL
        #mediaConvertRole = os.environ['MediaConvertRole']
        #region = os.environ['AWS_DEFAULT_REGION']
        jobTemplateARN = os.environ['JobTemplateARN']
        endPoint_url = os.environ['EndPoint_url']
    
        statusCode = 200
    
        try:    
            bucket = S3.Bucket(sourceS3Bucket)
            # Use job template mapping file to locate the correct job template json to use.
            jobTemplateMapping_json = {}
            jobTemplateJason = ""
            thumbnailS3 = ""
            with open('jobTemplateMapping.json') as j_data:
                jobTemplateMapping_json = json.load(j_data)
                for j in jobTemplateMapping_json['JobTemplats']:
                    if j['JobTemplateName'] == jobTemplateName: 
                        jobTemplateJason = j['JobJson']
                        thumbnailS3 = 's3://' + j['ThumbnailS3']
                        mediaConvertRole = j['JobRole']
                    
            logger.info(jobTemplateJason)
            print("jobTemplateJason: " + jobTemplateJason)
            print("thumbnailS3: " + thumbnailS3)
            if jobTemplateJason == "":
                statusCode = 404
                return {
                    'statusCode': statusCode,
                    'body': 'Job Template Json does not exist',
                    'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'}
                }
                    
            # Use job template json file to construct convert job
            job_json = {}   
            #with open('job.json') as json_data:
            with open(jobTemplateJason) as json_data: 
                job_json = json.load(json_data)            
                job_json['JobTemplate'] = jobTemplateARN + '/' + jobTemplateName
                job_json['Role'] = mediaConvertRole
                for outputgroup in job_json['Settings']['OutputGroups']:
                    if outputgroup['OutputGroupSettings']['Type'] == 'HLS_GROUP_SETTINGS':
                        outputgroup['OutputGroupSettings']['HlsGroupSettings']['Destination'] = destinationS3 + '/' + assetID + '/' + assetID + '_' + outputgroup['CustomName'] + '/index'
                    elif outputgroup['OutputGroupSettings']['Type'] == 'FILE_GROUP_SETTINGS':
                        outputgroup['OutputGroupSettings']['FileGroupSettings']['Destination'] = thumbnailS3 + '/' + assetID + '/' + assetID + '_' + outputgroup['CustomName'] + '/index'
                
                job_json['Settings']['Inputs'][0]['FileInput'] = sourceS3
                logger.info(json.dumps(job_json))
                print("job_json: " + json.dumps(job_json))
                 
            # get the account-specific mediaconvert endpoint for this region
            mediaconvert_client = boto3.client('mediaconvert', endpoint_url=endPoint_url)
            logger.info(endPoint_url)
            print("endpoint_url: " + endPoint_url)
            job = mediaconvert_client.create_job(**job_json)

        except Exception as e:
            logger.error('Exception: %s', e)
            statusCode = 500
            raise

        finally:
            return {
                'statusCode': statusCode,
                'body': json.dumps(job, indent=4, sort_keys=True, default=str),
                'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'}
            }
