import json
import sys
import base64
from Crypto.Cipher import AES
from Crypto import Random
from Crypto.Protocol.KDF import PBKDF2
import socket,struct
from ipaddress import ip_network, ip_address


BLOCK_SIZE = 16
pad = lambda s: s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * chr(BLOCK_SIZE - len(s) % BLOCK_SIZE)
unpad = lambda s: s[:-ord(s[len(s) - 1:])]

def lambda_handler(event, context):
    event_path = event["requestContext"]["resourcePath"]
    '''
    1. POST /token/create HTTP/1.1 Content-Type: application/json
       To create token
    2. POST /token/read HTTP/1.1 Content-Type: application/json
       To decrypt token in plain text
    3. POST /token/validate HTTP/1.1 Content-Type: application/json
       To validate the token
    '''
    if event_path == "/token/create":
        """ 
        create json sample. Create token
        {
            
            "start_time": "1590556618",
            "duration": "3600",   // value in second. if leave "" will have no end time
            "stream_id": "aflvideo_1",
            "ipv4": "203.41.5.0",   //leave 0.0.0.0 for any source IP
            "mask": "24",   //leave 0 for any source mask
            "password": "Telstra.123"
        }
        """
        event_body = event["body"]
        event_body_json = json.loads(event_body)
        start_time = event_body_json["start_time"]
        duration = event_body_json["duration"]
        stream_id = event_body_json["stream_id"]
        ipv4 = event_body_json["ipv4"]
        mask = event_body_json["mask"]
        password = event_body_json["password"]
        token_str = start_time + "|" + duration + "|" + stream_id + "|" + ipv4 + "|" + mask
        # Encrypt secret message
        """
        encrypted_byte = encrypt(token_str, password)
        print("encrypted_byte: " + str(encrypted_byte))
        encrypted_str = str(encrypted_byte, 'utf-8')
        print("encrypted_str: " + encrypted_str)
        
        # Convert to Base64
        encrypted_str_base64 = base64.b64encode(encrypted_byte)
        print("encrypted_str_base64: "+ str(encrypted_str_base64))
        encrypted_str_base64_str = encrypted_str_base64.decode('utf-8')
        print("encrypted_str_base64_str: " + encrypted_str_base64_str)
        """
        encrypted_base64_str = encrypt(token_str, password)
        return {
            'statusCode': 200,
            'body': encrypted_base64_str
            
        }
    elif event_path == "/token/read":
        """ 
        read json sample. Based on token return token in text.
        {
            "decrypt": "/gx+YlW4DwhptOJslaGzai8xsVUr++ThmNLIP/TNTEUnKEE/nCpHOqE/f3FvG6z53M9zZiALroQHaWPPJxyNqQ==",
            "password": "Telstra.123"
        }
        """
        # Let us decrypt using our original password
        event_body = event["body"]
        event_body_json = json.loads(event_body)
        decrypt_base64_str = event_body_json["decrypt"]
        password = event_body_json["password"]
        print("decrypt_base64_str: " + decrypt_base64_str)
        """
        # Convert Base64 to str
        decrypt_str_byte = base64.b64decode(bytes(decrypt_base64_str, 'utf-8'))
        print("decrypt_str_byte: " + str(decrypt_str_byte))
        decrypt_str = decrypt_str_byte.decode('utf-8')
        print("decrypt_str: " + decrypt_str)
        """
        token_str = parse_token(decrypt_base64_str, password)
        if token_str == "none":
            token_str = '{"error": "token parse failed"}'
        """ return token text 
        {
            "start_time": "1590840674",
            "duration": "7200",
            "stream_id": "aflvideo_1",
            "ipv4": "203.41.5.0",
            "mask": "24"
        }
        """
        return {
            'statusCode': 200,
            'body': token_str   
        }
    elif event_path == "/token/validate":
        """ validate json sample. Compare token and encoder source IP and IP to authorize rtmp stream. 
        {
            "decrypt": "/gx+YlW4DwhptOJslaGzai8xsVUr++ThmNLIP/TNTEUnKEE/nCpHOqE/f3FvG6z53M9zZiALroQHaWPPJxyNqQ==",
            "password": "Telstra.123",
            "enc_start_time: "1590556618",   //epoc time
            "enc_ip": "203.41.5.2"
        }
        """
        event_body = event["body"]
        event_body_json = json.loads(event_body)
        decrypt_str = event_body_json["decrypt"]
        password = event_body_json["password"]
        enc_ip = str(event_body_json["enc_ip"])
        enc_start_time = event_body_json["enc_start_time"]
        #print(decrypt_str)
        
        token_str = parse_token(decrypt_str, password)
        #print(token_str)
        
        if token_str == "none":
            return {
                'statusCode': 403,
                'body': 'token parse failed'
            }
        else:
            
            token_json = json.loads(token_str)
            token_start_time = token_json["start_time"]
            token_duration = token_json["duration"]
            token_ipv4 = str(token_json["ipv4"])
            token_mask = str(token_json["mask"])
            token_stream_id = str(token_json["stream_id"])
            token_net = token_ipv4 + "/" + token_mask
            token_start_time = int(token_start_time)
            enc_time = int(enc_start_time)
       
            #result = ip_in_prefix(enc_ip, token_net)
            ip_result = ip_in_net(enc_ip, token_net)
        
            if enc_time < token_start_time:
                print("Encoder starts before token is allowed start time.")
                return {
                    'statusCode': 403,
                    'body': "Encoder starts before token is allowed start time."
                }
            if token_duration != "":
                token_end_time = int(token_start_time) + int(token_duration)
                if enc_time >= token_end_time:
                    print("Token has expired.")
                    return {
                        'statusCode': 403,
                        'body': "Token has expired."
                    }
                
            if ip_result == "False":
                print("Source IP is not allowed.")
                return {
                    'statusCode': 403,
                    'body': "Souce IP is not allowed."
                }
            print("token_stream_id")
            return {
                'statusCode': 200,
                'body': token_stream_id
            }
            #print("I am nowhere.")

    else:
        print("Invalid value")
        return {
            'statusCode': 400,
            'body': "Invalid value."
        }
    
    
def encrypt(raw, password):
    private_key = get_private_key(password)
    raw = pad(raw)
    iv = Random.new().read(AES.block_size)
    cipher = AES.new(private_key, AES.MODE_CBC, iv)
    encrypted_byte = base64.b64encode(iv + cipher.encrypt(raw))
    # Convert to Base64
    encrypted_str_base64 = base64.b64encode(encrypted_byte)
    print("encrypted_str_base64: "+ str(encrypted_str_base64))
    encrypted_str_base64_str = encrypted_str_base64.decode('utf-8')
    print("encrypted_str_base64_str: " + encrypted_str_base64_str)
    return encrypted_str_base64_str

def get_private_key(password):
    #salt = b"TelstraMediaHE"
    #private key is a UUID4 value
    salt = b"932b2afefb684ff3b85e91a67e9562af"
    
    try:
        kdf = PBKDF2(password, salt, 64, 1000)
        key = kdf[:32]
        return key
    except Exception as error:
        print('Inside the except block: ' + repr(error))
        return "none"
        
def decrypt(enc, password):
    private_key = get_private_key(password)
    try:
        enc = base64.b64decode(enc)
        iv = enc[:16]
        cipher = AES.new(private_key, AES.MODE_CBC, iv)
        return unpad(cipher.decrypt(enc[16:]))
    except Exception as error:
        print('Inside the except block: ' + repr(error))
        return "none"
    
def parse_token(decrypt_base64_str, password):
    # Convert Base64 to str
    decrypt_str_byte = base64.b64decode(bytes(decrypt_base64_str, 'utf-8'))
    print("decrypt_str_byte: " + str(decrypt_str_byte))
    decrypt_str = decrypt_str_byte.decode('utf-8')
    print("decrypt_str: " + decrypt_str)
    
    decrypt_byte = decrypt_str.encode()
    print(decrypt_byte)
    dec = decrypt(decrypt_str, password)
    if dec == "none":
        #return '{"error": "token parse failed"}'
        return "none"
    else:
        try:
            dec = decrypted_str = bytes.decode(dec)
            decrypted_data = decrypted_str.split("|")
            start_time = decrypted_data[0]
            duration = decrypted_data[1]
            stream_id = decrypted_data[2]
            ipv4 = decrypted_data[3]
            mask = decrypted_data[4]
            token_str = '{"start_time": "' + start_time + '", "duration": "' + duration + '", "stream_id": "' + stream_id + '", "ipv4": "' + ipv4 + '", "mask": "' + mask + '"}'
            return token_str
        except Exception as error:
            print('Inside the except block: ' + repr(error))
            return "none"

def ip_in_net(enc_ip, token_net):
    #net = ip_network(token_net)
    net = ip_network(token_net, False)
    #print("token_net:" + net)
    res = (ip_address(enc_ip) in net)
    return str(res)