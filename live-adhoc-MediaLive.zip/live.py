import json
import boto3
import botocore
import time
import pprint
import random
import time
import os

eml_role_arn = os.environ['MediaLiveRoleARN']

eml_client = boto3.client('medialive')

def handler(event, context):
    #channel_name = "aflvideo_1"
    channel_name = event['pathParameters']['channelname']
    channel_operation = event['pathParameters']['opt']
    channel_id = eml_get_channel_id(channel_name)
    result_code = 400
    print("channel_id: " + channel_id)
    print("channel_name: " + channel_name)
    print("opt: " + channel_operation)
    if channel_id == "none":
        return {
            'statusCode': 404,
            'body': "Channel does not exit."
        }
    else:
        if channel_operation == "start":
            result = eml_client.start_channel( ChannelId=channel_id)
            if result['State'] == "STARTING" or result['State'] == "RUNNING":
                result_code = 200
        elif channel_operation == "stop":
            result = eml_client.stop_channel( ChannelId=channel_id)
            if result['State'] == "STOPPING" or result['State'] == "IDLE":
                result_code = 200
        elif channel_operation == "status":
            result_code = 200
        else:
            return {
                'statusCode': 400,
                'body': 'Operation is not allowed. Please specify the correct operation.'
            }
        response = eml_client.describe_channel( ChannelId=channel_id )
        state = response['State']
        return {
            'statusCode': result_code,
            'body': channel_name + " is " + state
        }
        
        
        
def eml_get_channel_id(chName):
    response = eml_client.list_channels()
    channel_id = "none"
    for channel in response['Channels']:
        if channel['Name'] == chName:
            try:
                channel_id = channel['Id']
            except botocore.exceptions.ClientError as e:
                print( e.response['Error']['Code'] )
    return channel_id
    
