import glob
import json
import os
import boto3
from boto3.dynamodb.conditions import Key, Attr

db_medialive = os.environ['DynamoDBMediaLiveName']
db_medialive_client = boto3.resource('dynamodb')
table_medialive = db_medialive_client.Table(db_medialive)

db_wow = os.environ['DynamoDBWowName']
db_wow_client = boto3.resource('dynamodb')
table_wow = db_medialive_client.Table(db_wow)
data = {}

def handler(event, context):
    db_medialive = os.environ['DynamoDBMediaLiveName']
    db_medialive_client = boto3.resource('dynamodb')
    table_medialive = db_medialive_client.Table(db_medialive)

    db_wow = os.environ['DynamoDBWowName']
    db_wow_client = boto3.resource('dynamodb')
    table_wow = db_medialive_client.Table(db_wow)
    data = {}

    try:
        response = table_wow.scan()
        if response["Count"] == 0:
            return {
                'statusCode': 200,
                'body': data
            }
        else:
            data['list'] = [] 
            for it in response['Items']:
                attributes = table_medialive.query(
                    IndexName = 'channel_name-index',
                    KeyConditionExpression=Key('channel_name').eq(it['stream_id'])
                )
                print(attributes)
                channel_id = attributes['Items'][0]['channel_id']
                channel_state = attributes['Items'][0]['state']
                stream = {'stream_name': it['stream_id'], 'channel_id': channel_id, 'channel_state': channel_state}
                data['list'].append(stream)

            return {
                'statusCode': 200,
                'body': data
            }
    except Exception as e:
        print("Exception: " + str(e))
        raise



