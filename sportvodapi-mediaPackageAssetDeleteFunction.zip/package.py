import glob
import json
import os
import uuid
import boto3
import datetime
import random
from urllib.parse import urlparse
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    '''
    package.py read input json which defines the VOD encoded file location and packagegroup.
    Delete VOD package asset. POST /vodpackage/delete_asset
        {
            "Record": {
                "Platform": "1",     // Encoding platform. 1 - AWS MediaService
                "AssetID": "sample4"
            }
            
        }
    '''
    job_body = {}
    job_body = json.loads(event['body'])
    
    
    if job_body['Record']['Platform'] == "1": 
        assetID = job_body['Record']['AssetID']
        statusCode = 200
        res = {}
    
        try:
            client = boto3.client('mediapackage-vod')
            res = client.delete_asset(Id=assetID)

    
        except Exception as e:
            logger.error('Exception: %s', e)
            statusCode = 500
            raise

        finally:
            return {
                'statusCode': statusCode,
                'body': json.dumps(res, indent=4, sort_keys=True, default=str),
                'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'}
            }

