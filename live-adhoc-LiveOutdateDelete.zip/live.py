import glob
import json, hashlib, os, boto3, datetime, hmac
import random
import time
import base64
#from datetime import datetime
import logging
from urllib import request, parse
from boto3.dynamodb.conditions import Key, Attr

def handler(event, context):
    current_datetime = datetime.datetime.now()
    ts = round(current_datetime.timestamp())
    db = os.environ['DynamonDBName']
    client = boto3.resource('dynamodb')
    table = client.Table(db)
    defer_time = os.environ['Defer']    ##defer time in second to stop medialive channel
 
    try:
        
        ## Go through DynamonDB to filter out the stale live stream and stop live channel
        stale_time = int(ts) - int(defer_time) - 10
        print("stale_time: " + str(stale_time))
        #response = table.scan(
        #    FilterExpression = Attr('last_seen').lt(stale_time)
        #)
        response = table.scan(
            FilterExpression = Attr('last_seen').lt(stale_time)
        )
        print(response['Items'])
        
        ## Stop stale live channels
        for it in response['Items']:
            #print(it)
            stale_steam_id = it['stream_id']
            print("stale stream id: " + stale_steam_id)
            '''
            medialive_api_url = mediaLive_api + "?channelName=" + stale_steam_id + "&opt=stop"
            data = {}
            param = json.dumps(data).encode('utf8')
            req = request.Request(medialive_api_url, data=param, headers={'content-type': 'application/json'})
            '''
            result = stop_channel(stale_steam_id)
            
            # remove record from DynamonDB if stop is successful
            if result == 200:
                response = table.delete_item(
                    Key={
                        'stream_id': stale_steam_id
                    }
                )
           
    except Exception as e:
        print('Exception: ' + str(e))
        statusCode = 500
        raise

def sign(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

def getSignatureKey(key, dateStamp, regionName, serviceName):
    kDate = sign(('AWS4' + key).encode('utf-8'), dateStamp)
    kRegion = sign(kDate, regionName)
    kService = sign(kRegion, serviceName)
    kSigning = sign(kService, 'aws4_request')
    return kSigning

def stop_channel(stream_name):
    method = 'GET'
    service = 'execute-api'
    host = os.environ['MediaLiveAPIHost']
    region = os.environ['AWS_Region']
    stage = os.environ['MediaLiveAPIStage']
    endpoint = 'https://' + host
    request_parameters = ''
    
    # Read AWS access key 
    secret_name = os.environ['Secret_Name']
    access_key = os.environ['Access_Key']
    secret = get_secret(secret_name)
    secret_json = json.loads(secret)
    secret_key = secret_json[access_key]
    
    # Create a date for headers and the credential string
    t = datetime.datetime.utcnow()
    amzdate = t.strftime('%Y%m%dT%H%M%SZ')
    datestamp = t.strftime('%Y%m%d')
    
    # Create canonical URI--the part of the URI from domain to query 
    #canonical_uri = '/prod/tlab_telint_1/stop'
    canonical_uri = '/' + stage + '/' + stream_name + '/stop'
    
    canonical_querystring = request_parameters 
    canonical_headers = 'host:' + host + '\n' + 'x-amz-date:' + amzdate + '\n'
    
    # Create the canonical headers and signed headers, For requests that use query strings, only "host" is included in the signed headers
    signed_headers = 'host;x-amz-date'
    
    # Create payload hash. For GET requests, the payload is an empty string ("")
    payload_hash = hashlib.sha256(('').encode('utf-8')).hexdigest()
    
    # Combine elements to create canonical request
    canonical_request = method + '\n' + canonical_uri + '\n' + canonical_querystring + '\n' + canonical_headers + '\n' + signed_headers + '\n' + payload_hash
    
    algorithm = 'AWS4-HMAC-SHA256'
    credential_scope = datestamp + '/' + region + '/' + service + '/' + 'aws4_request'
    
    # CREATE THE STRING TO SIGN
    string_to_sign = algorithm + '\n' +  amzdate + '\n' +  credential_scope + '\n' +  hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()
    
    # Create the signing key
    signing_key = getSignatureKey(secret_key, datestamp, region, service)
    
    # Sign the string_to_sign using the signing_key
    signature = hmac.new(signing_key, (string_to_sign).encode("utf-8"), hashlib.sha256).hexdigest()
    
    authorization_header = algorithm + ' ' + 'Credential=' + access_key + '/' + credential_scope + ', ' +  'SignedHeaders=' + signed_headers + ', ' + 'Signature=' + signature
    headers = {'x-amz-date':amzdate, 'Authorization':authorization_header}
    
    request_url = endpoint + canonical_uri
    
    req = request.Request(request_url)
    req.add_header('x-amz-date', amzdate)
    req.add_header('Authorization', authorization_header)
    
    try:
        #res = urllib.request.urlopen(request_url)
        res = request.urlopen(req)
    except request.HTTPError as exception:
                
        print("stop " + stream_name + " not successful due to " + str(exception))
        return 400
        raise
    else:
        print("stop " + stream_name + " successful")
        return 200
    #finally:
    #    return "good"
    

def get_secret(secret_name):
    
    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager'
    )

    get_secret_value_response = client.get_secret_value(
        SecretId=secret_name
    )
    secret = get_secret_value_response['SecretString']
    return secret
