import glob
import json, hashlib, os, boto3, datetime, hmac
import random
import time
import base64
#from datetime import datetime
import logging
from urllib import request, parse
from boto3.dynamodb.conditions import Key, Attr

def handler(event, context):
    current_datetime = datetime.datetime.now()
    ts = round(current_datetime.timestamp())
    tokenFunctionArn = os.environ['TokenFunctionArn']
    mediaLiveRoleARN = os.environ['MediaLiveRoleARN']
    token = ""

    """ 
    Read input json 
    {
         
        "token_creation": "false",   //to create stream token
        "start_time": "1590556618",   //live service avaialbe start time
        "duration": "3600",   // value in second. if leave "" will have no end time
        "stream_id": "aflvideo_1",   //stream name. It will be used for medialive channel name
        "ipv4": "203.41.5.0",   //leave 0.0.0.0 for any source IP
        "mask": "24",   //leave 0 for any source mask
        "password": "Telstra.123",  //private key. Will be provided by Video Engineer
        "channel_creation": "false",   //to create MediaLive channel and MediaPackage service
        "template: "s3://live-adhoc-m-template/live_adhoc.template"   //location of the mediaservice template file
    }
    """
 
    try:
        event_body = event["body"]
        event_body_json = json.loads(event_body)
        channelName = event_body_json["stream_id"]
        if event_body_json["token_creation"] == "true":
            startTime = event_body_json["start_time"]
            duration = event_body_json["duration"]
            ipv4 = event_body_json["ipv4"]
            mask = event_body_json["mask"]
            password = event_body_json["password"]
            payloadBody = {"start_time": startTime , "duration": duration, "stream_id": channelName, "ipv4": ipv4, "mask": mask, "password": password}
            payload = {'requestContext': {'resourcePath': '/token/create'}, 'body': json.dumps(payloadBody)}
            print(payload)
            lambda_client = boto3.client('lambda')
            response = lambda_client.invoke(
                FunctionName = tokenFunctionArn,
                InvocationType = 'RequestResponse',
                Payload = json.dumps(payload)
            )
            responseJson = json.load(response['Payload'])
            print(responseJson)
            token = responseJson['body']
            returnBody = {"token": token}

        if event_body_json["channel_creation"] == "true":
            template = event_body_json["template"]
            input1 = event_body_json["rtmp_input1"]
            input2 = event_body_json["rtmp_input2"]
            print("template: " + template)
            cloudformation_client = boto3.client('cloudformation')
            response = cloudformation_client.create_stack(
                StackName=channelName,
                TemplateURL=template,
                Parameters=[
                    {
                        'ParameterKey': 'MediaLiveInput1',
                        'ParameterValue': input1
                    },
                    {
                        'ParameterKey': 'MediaLiveInput2',
                        'ParameterValue': input2
                    },
                    {
                        'ParameterKey': 'MediaLiveRoleARN',
                        'ParameterValue': mediaLiveRoleARN
                    }
               ]
            )
            print(response)


        return {
            'statusCode': 200,
            'body': json.dumps(returnBody)
        }
    except Exception as e:
        print('Exception: ' + str(e))
        statusCode = 500
        raise



