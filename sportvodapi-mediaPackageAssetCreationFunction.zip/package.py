import glob
import json
import os
import uuid
import boto3
import datetime
import random
from urllib.parse import urlparse
import logging

from botocore.client import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    '''
    package.py read input json which defines the VOD encoded file location and packagegroup.
    Create VOD package asset. POST /vodpackage/create_asset
        {
            "Record": {
                "Platform": "1",     // Encoding platform. 1 - AWS MediaService
                "AssetID": "sample4",
                "PackagingGroupId": "telstra-vod-packaging-group",
                "ResourceId": "",
                "SourcePath": "s3://telstra-awsvod-encoded/bo1/TelstraLiveStream.m3u8"    //package input file location
            }
            
        }
    '''
    job_body = {}
    job_body = json.loads(event['body'])
    
    if job_body['Record']['Platform'] == "1": 
        assetID = job_body['Record']['AssetID']
        packagingGroupId =  job_body['Record']['PackagingGroupId']
        sourcePathFile = job_body['Record']['SourcePath']
        sourcePathFile = sourcePathFile.split("s3://", 1)[1]
        sourcePath = sourcePathFile.split("/", 1)[0]
        sourceKey = sourcePathFile.split("/", 1)[1]
        resourceID = job_body['Record']['ResourceId']
        print("sourcePath: " + sourcePath)
        # Verify if output group is configured with DRM but resource ID is not defined in API call, return error
        if "drm" in packagingGroupId and resourceID == "":
            err = "{'error': 'ResourceID is required for DRM package group'}"
            return {
                'statusCode': 400,
                'body': json.dumps(err, indent=4, sort_keys=True, default=str),
                'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'}
            }
            
            
        if resourceID == "":
            resourceID = "null"
        print("resourceID: " + resourceID)
        s3ARN = ""
        
#        with open('s3Bucket.json') as s_data:
#            s3Bucket_json = json.load(s_data)
#            for s in s3Bucket_json['S3Buckets']:
#                if s['S3Name'] == sourcePath: 
#                    s3ARN = s['s3ARN']
        #sourceArn = job_body['Record']['SourceArn']
        sourceArn = "arn:aws:s3:::" + sourcePath + "/" + sourceKey
        print("sourceArn: " + sourceArn)
        #find source role ARN
        with open('pkgRole.json') as r_data:
            roles_json = json.load(r_data)
            for r in roles_json['roles']:
                if r['packageGroup'] == packagingGroupId: 
                    sourceRoleArn = r['role']
        
        print("sourceRoleArn: " + sourceRoleArn)
        statusCode = 200
        res = {}
    
        try:
    
            client = boto3.client('mediapackage-vod')
            res = client.create_asset(Id=assetID, PackagingGroupId=packagingGroupId, ResourceId=resourceID, SourceArn=sourceArn, SourceRoleArn=sourceRoleArn, Tags={})
            print(statusCode)
            
            # Find the CDN
            '''
            url_cdn = ""
            with open('vodPkgCDNMapping.json') as j_data:
                cdnMapping_json = json.load(j_data)
                for j in cdnMapping_json['cdns']:
                    if j['PackagingGroupId'] == packagingGroupId: 
                        url_cdn = j['CDN']
                        
            # Replace with CDN URL            
            for u in res['EgressEndpoints']:
                endpoint_url = u['Url']
                endpoint_uri = endpoint_url.split('/out')[1]
                endpoint_cdn = "https://" + url_cdn + "/out" + endpoint_uri
                u["Url"] = endpoint_cdn
                print(endpoint_cdn)
            '''
    
        except Exception as e:
            print('Exception: %s', e)
#            print("here error")
            statusCode = 500
            raise

        finally:
            return {
                'statusCode': statusCode,
                'body': json.dumps(res, indent=4, sort_keys=True, default=str),
                'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'}
            }

