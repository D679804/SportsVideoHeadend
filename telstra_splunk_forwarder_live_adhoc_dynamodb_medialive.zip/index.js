/**
 * Stream events from AWS CloudWatch Logs to Splunk
 *
 * This function streams AWS CloudWatch Logs to Splunk using
 * Splunk's HTTP event collector API.
 *
 * Define the following Environment Variables in the console below to configure
 * this function to stream logs to your Splunk host:
 *
 * 1. SPLUNK_HEC_URL: URL address for your Splunk HTTP event collector endpoint.
 * Default port for event collector is 8088. Example: https://host.com:8088/services/collector
 *
 * 2. SPLUNK_HEC_TOKEN: Token for your Splunk HTTP event collector.
 * To create a new token for this Lambda function, refer to Splunk Docs:
 * http://docs.splunk.com/Documentation/Splunk/latest/Data/UsetheHTTPEventCollector#Create_an_Event_Collector_token
 */
const loggerConfig = {
    url: process.env.SPLUNK_HEC_URL,
    token: process.env.SPLUNK_HEC_TOKEN,
};

const SplunkLogger = require('./lib/mysplunklogger');
const zlib = require('zlib');
const logger = new SplunkLogger(loggerConfig);




exports.handler = (event, context, callback) => {
    let count=0;
    
    for (const record of event.Records) {
        console.log(record.eventID);
        console.log(record.eventName);
        console.log('DynamoDB Record: %j', record.dynamodb);
        
        logger.logEvent({
             time: new Date().getTime() / 1000,
             host: 'aws',
             source: 'telstra_splunk_forwarder_live_adhoc_dynamodb_medialive',
             sourcetype: 'live-adhoc-DynamoDBTable-medialive',
             index: 'aws-vhe-app-s',
             event:  record,
        });
       
        }
 // Send all the events in a single batch to Splunk
        logger.flushAsync((error, response) => {
            if (error) {
                callback(error);
            } else {
                console.log(`Response from Splunk:\n${response}`);
                console.log(`Successfully processed ${count} log event(s).`);
                callback(null, count); // Return number of log events
            }
        });
};


