import glob
import json
import os
import boto3
import datetime
import random

eml_client = boto3.client('medialive')
epl_client = boto3.client('mediapackage')
db = os.environ['DynamoDBName']
db_client = boto3.resource('dynamodb')
table = db_client.Table(db)


def handler(event, context):
    channel_arn = event['detail']['channel_arn']
    channel_id = channel_arn.rsplit(':', 1)[1]
    channel_state = event['detail']['state']
    
    current_datetime = datetime.datetime.now()
    ts = round(current_datetime.timestamp())
    
    print(channel_id + " change state " + channel_state)
    try:
        if channel_state == "CREATED":
            response = eml_client.describe_channel( ChannelId=channel_id )
            channel_name = response['Name']
            if (channel_name[:3]) == "ad-":
                channel_type = "adhoc"
            else:
                channel_type = "permanent"

            table.put_item(Item = {
                'channel_id': channel_id,
                'channel_name': channel_name,
                'state': channel_state,
                'channel_type': channel_type,
                'update_time': ts
            })
            
            egressLog = '/aws/MediaPackage/out'
            ingressLog = '/aws/MediaPackage/in'
            res = epl_client.configure_logs(
                EgressAccessLogs={'LogGroupName': egressLog},
                Id=channel_name,
                IngressAccessLogs={'LogGroupName': ingressLog}
            )

        elif channel_state == "DELETED":
            table.delete_item(
                Key={
                    'channel_id': channel_id
                }
            )
            
        else:
            table.update_item(
                Key = {'channel_id': channel_id},
                AttributeUpdates = {'state': {'Action': 'PUT', 'Value': channel_state}}
            )
            table.update_item(
                Key = {'channel_id': channel_id},
                AttributeUpdates = {'update_time': {'Action': 'PUT', 'Value': ts}}
            )
            

    except Exception as e:
        print("Exception: " + str(e))
        raise

