import glob
import json, hashlib, os, boto3, datetime, hmac
import random
import time
import base64
#from datetime import datetime
import logging
from urllib import request, parse
from boto3.dynamodb.conditions import Key, Attr

def handler(event, context):
    current_datetime = datetime.datetime.now()
    ts = round(current_datetime.timestamp())
    db = os.environ['DynamonDBName']
    client = boto3.resource('dynamodb')
    table = client.Table(db)
    
    try:
        ## Fetch wowza active live stream status and update DynamonDB
        with open('conf.json') as j_data:
            conf_json = json.load(j_data)
            for j in conf_json['configs']:
                url = j['url']
                username = j['user']
                passwd = j['pass']
                
                print("url: " + url)
                #req = request.Request(url)
                #req.add_header('Accept', 'application/json')
                #res = request.urlopen(req)
                
                req = request.Request(url)
                credentials = ('%s:%s' % (username, passwd))
                encoded_credentials = base64.b64encode(credentials.encode('ascii'))
                req.add_header('Authorization', 'Basic %s' % encoded_credentials.decode("ascii"))
                req.add_header('Accept', 'application/json')
                res = request.urlopen(req)
                
                res_body = res.read()
                res_body_json = json.loads(res_body.decode("utf-8"))
                print(res_body_json)
                
                if len(res_body_json['instanceList']) != 0:
                    ## Parse the incoming streams from json
                    for i in res_body_json['instanceList'][0]['incomingStreams']:
                        streamID = i['name']
                        
                        ## Update record in DynamonDB
                        
                        table.put_item(Item = {
                            'stream_id': streamID,
                            'last_seen': ts
                        })
    except Exception as e:
        print("Exception: " + str(e))
        statusCode = 500
        raise
